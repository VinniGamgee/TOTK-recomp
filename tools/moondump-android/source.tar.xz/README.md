# MoonDump — Android ARM64 (0.1-alpha)

**Estado:** protótipo de código-fonte. Ainda **não validado em aparelho real** e **não é um APK pronto**. Implementado para demonstrar um caminho independente de emulador, visando o POCO F5 / Android moderno. O backend é compilado do Hactool original (licença ISC), não do NxDump nem do Citron. Nenhuma ROM, chave, firmware ou binário de terceiros é distribuído neste ZIP.

## O que contém

- Aplicativo Android Java independente (minSdk 30, targetSdk 35), com foreground service de uso especial para extrações longas.
- Extração NSP (PFS0) ou XCI (partição secure), seleção de NCA `Program` por metadados.
- ExeFS e RomFS base; opção experimental `--basenca` para mesclar um update NSP ao extrair a NCA patch.
- Escrita direta em `/storage/emulated/0` com permissão **Acesso a todos os arquivos** (Android 11+); NÃO utiliza SAF para cada arquivo de saída.
- Pequeno patch do Hactool que escreve em `*.mdpart` e renomeia ao concluir. Arquivos finalizados de **tamanho correto** são pulados em nova execução. Não retoma um arquivo no meio; refaz apenas arquivos incompletos. A verificação de erro de escrita é feita antes de renomear; não há `fsync` a cada arquivo, para evitar excesso de sincronizações no armazenamento.
- Serviço em primeiro plano e arquivo `moondump.log` para investigar falhas.

## Limitações reais

1. **Ainda não testado no Android 17**. O executável PIE renomeado para `libmoondump_core.so` é empacotado como biblioteca nativa por conveniência, mas a execução direta dessa forma depende da versão do Android / políticas do aparelho.
2. **Não importa automaticamente as title keys do ticket dentro de NSP**. Um NCA com Rights ID pode exigir `--titlekey=<hex>` extraído legitimamente do próprio console/jogo; `prod.keys` não basta em todos os casos. Não cole chaves em issues nem as compartilhe.
3. A preparação NSP/XCI **primeiro extrai NCAs temporários**, então exige espaço *adicional* para NCAs + RomFS final, podendo chegar a dezenas de GB. O programa não remove os temporários automaticamente para permitir retomada.
4. A escolha de Program NCA usa o campo textual do Hactool. Nem toda variação de jogo/update foi validada. Update 1.4.3 do TOTK não foi testado.
5. A retomada é por arquivo cujo **tamanho já coincide**. Não usa hash de conteúdo para verificar arquivos prévios; use uma pasta de saída NOVA na primeira execução. Não confundir com retomada de bytes dentro de um arquivo grande.
6. Pode não funcionar com NSP contendo tickets não suportados ou formato NSZ/XCZ. Não é uma ferramenta de contorno de DRM nem fornece material protegido.
7. App de distribuição privada: `MANAGE_EXTERNAL_STORAGE` normalmente não atende requisitos de publicação na Play Store para apps que não sejam gerenciadores de arquivos.
8. Não existe medição real de velocidade no POCO F5. A extração nativa pode ser mais rápida por evitar SAF, mas o projeto faz mais operações de leitura/gravação que uma extração direta sem staging.

## Como compilar SEM PC (GitHub Actions)

1. Crie um repositório GitHub **novo e privado**, por exemplo `MoonDump-Android`.
2. Envie os arquivos **incluindo a pasta oculta `.github/workflows/`** para a raiz do repositório (o app do GitHub / navegador permite upload de arquivos; extrair este ZIP no celular ajuda).
3. Em **Actions**, selecione `Build MoonDump Android APK (ARM64)` e `Run workflow` ou envie commit para `main`.
4. Se o CI ficar verde, abra a execução → **Artifacts** → `MoonDump-Android-ARM64-debug-APK` → baixe/extraia o APK.
5. Instale no Android e conceda "Acesso a todos os arquivos" ao MoonDump.
6. Ajuste os caminhos de NSP, prod.keys e a pasta final. Se houver update, experimente primeiro sem ele para validar a base.
7. Preserve a pasta de saída em caso de erro. O botão "Começar / retomar" usa os arquivos existentes.

## Segurança e licenças

Core externo original: https://github.com/SciresM/hactool (ISC, copyright SciresM). `scripts/patch_hactool.py` altera temporariamente uma função durante a build, sem republicar o código do Hactool neste ZIP. O Hactool inclui dependências com outras licenças, incluindo mbedTLS (Apache 2.0). Respeite as licenças de dependências numa distribuição. Este projeto não inclui nenhum segredo, arquivos de jogos ou executáveis pré-compilados.
