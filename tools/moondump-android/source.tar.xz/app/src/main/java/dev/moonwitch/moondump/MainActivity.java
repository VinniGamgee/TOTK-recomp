package dev.moonwitch.moondump;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.method.ScrollingMovementMethod;
import java.io.File;

public class MainActivity extends Activity {
    private EditText base, update, keys, titleKey, output;
    private TextView status;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable redraw = new Runnable() {
        public void run() {
            status.setText(ExtractService.state);
            handler.postDelayed(this, 700);
        }
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(20,24,32));
        getWindow().setNavigationBarColor(Color.rgb(20,24,32));
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setBackgroundColor(Color.rgb(20,24,32));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(30, 28, 30, 40);
        sc.addView(content);
        TextView title = new TextView(this);
        title.setText("MoonDump  0.1 α"); title.setTextSize(28);
        title.setTextColor(Color.WHITE); title.setTypeface(null, Typeface.BOLD);
        content.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Extrator ARM64 experimental • NSP / XCI → RomFS e ExeFS\nArquivos pessoais; nenhum jogo ou chave é distribuído.");
        subtitle.setTextColor(0xffacbad4); subtitle.setTextSize(13);
        content.addView(subtitle);
        addButton(content,"1 · Conceder acesso aos arquivos", () -> {
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:"+getPackageName()))); }
                catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
            }
        });
        final String root="/storage/emulated/0/Download/";
        base=field(content,"Arquivo base .NSP/.XCI (caminho absoluto)",root+"TOTK/base.nsp");
        update=field(content,"Update .NSP opcional (deixe vazio)","");
        keys=field(content,"prod.keys (extraído do seu console)",root+"TOTK/prod.keys");
        titleKey=field(content,"Title Key hex opcional (caso o NCA exija)","");
        output=field(content,"Pasta de saída (também armazena NCAs temporários)",root+"MoonDump-TOTK");
        TextView warning = new TextView(this);
        warning.setText("O Hactool precisa das chaves corretas. A versão α ainda não importa automaticamente title keys de tickets NSP. Reserve espaço para NCAs temporários + saída. Não apague a pasta ao interromper.");
        warning.setTextColor(0xffffc784); warning.setTextSize(13); warning.setPadding(0,18,0,12);
        content.addView(warning);
        addButton(content,"2 · Começar / retomar", () -> {
            if (!Environment.isExternalStorageManager()) { status.setText("Primeiro conceda acesso a todos os arquivos."); return; }
            Intent i=new Intent(this,ExtractService.class).setAction(ExtractService.START);
            i.putExtra("base",base.getText().toString().trim());
            i.putExtra("update",update.getText().toString().trim());
            i.putExtra("keys",keys.getText().toString().trim());
            i.putExtra("titlekey",titleKey.getText().toString().trim());
            i.putExtra("output",output.getText().toString().trim());
            try { startForegroundService(i); }
            catch (Exception e) { status.setText("Não iniciou: "+e); }
        });
        addButton(content,"Interromper (preserva arquivos)", () -> startService(new Intent(this,ExtractService.class).setAction(ExtractService.STOP)));
        status=new TextView(this); status.setTextSize(13);status.setTextColor(0xffc5d3ec);
        status.setPadding(12,20,12,20); status.setTextIsSelectable(true); status.setMovementMethod(new ScrollingMovementMethod());
        status.setMinLines(6);content.addView(status);
        setContentView(sc);
    }
    private EditText field(LinearLayout box,String label,String hint){
        TextView t=new TextView(this);t.setText(label);t.setTextSize(13);t.setTextColor(0xffa5b7d7);t.setPadding(0,16,0,0);box.addView(t);
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(Color.WHITE);e.setTextSize(14);e.setText(hint);e.setSelectAllOnFocus(true);box.addView(e);return e;
    }
    private void addButton(LinearLayout box,String name,Runnable action){
        Button btn=new Button(this);btn.setText(name);btn.setAllCaps(false);box.addView(btn);btn.setOnClickListener(v->action.run());
    }
    @Override protected void onStart(){super.onStart();handler.post(redraw);}
    @Override protected void onStop(){handler.removeCallbacks(redraw);super.onStop();}
}
