package dev.moonwitch.moondump;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.Build;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Experimental extraction service. The core binary is separately compiled from ISC-licensed Hactool. */
public final class ExtractService extends Service {
    static final String START="dev.moonwitch.moondump.START";
    static final String STOP="dev.moonwitch.moondump.STOP";
    public static volatile String state="Pronto. Configure os arquivos e inicie a extração.";
    private static final String CHANNEL="extract";
    private volatile Process runningProcess;
    private volatile boolean cancelled;
    private volatile boolean busy;
    private NotificationManager manager;
    private String recent="";
    private File logFile;

    @Override public void onCreate(){
        super.onCreate();
        manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,"MoonDump",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(STOP.equals(intent.getAction())){
            cancelled=true;
            Process p=runningProcess;
            if(p!=null)p.destroy();
            state="Interrompendo... os arquivos finalizados serão preservados.";
            return START_NOT_STICKY;
        }
        if(!START.equals(intent.getAction()) || busy)return START_NOT_STICKY;
        busy=true; cancelled=false;
        String base=intent.getStringExtra("base"), update=intent.getStringExtra("update"), keys=intent.getStringExtra("keys"), titlekey=intent.getStringExtra("titlekey"), output=intent.getStringExtra("output");
        if(Build.VERSION.SDK_INT>=34) startForeground(73,notification("Iniciando extração..."),ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(73,notification("Iniciando extração..."));
        Thread thread=new Thread(()->{
            try { runJob(base,update,keys,titlekey,output); }
            catch(Exception e){message("Falhou: "+e.getMessage());}
            finally{ busy=false; stopForeground(STOP_FOREGROUND_REMOVE);stopSelf(); }
        },"MoonDump-worker");
        thread.start();
        return START_NOT_STICKY;
    }
    private Notification notification(String message){
        return new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("MoonDump")
                .setContentText(message.length()>100?message.substring(0,100):message)
                .setOnlyAlertOnce(true).setOngoing(true).build();
    }
    private void message(String message){
        if(message.contains("--titlekey=") || message.contains("titlekek"))message="[detalhes de chave ocultos]";
        recent=(recent+"\n"+message);
        if(recent.length()>3500)recent=recent.substring(recent.length()-3500);
        state=recent.trim();
        manager.notify(73,notification(message));
        if(logFile!=null)try(BufferedWriter out=new BufferedWriter(new FileWriter(logFile,true))){out.write(message);out.newLine();}catch(IOException ignored){}
    }
    private static String sha(String s) throws Exception{
        byte[] bytes=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder out=new StringBuilder();for(int i=0;i<12;i++)out.append(String.format(Locale.ROOT,"%02x",bytes[i]));return out.toString();
    }
    private void ensureNotCancelled() throws IOException{if(cancelled)throw new IOException("Operação interrompida pelo usuário");}
    private void runJob(String base,String update,String keys,String titlekey,String output) throws Exception {
        recent="";
        File baseFile=assertReadable(base,"NSP/XCI base");
        File keysFile=assertReadable(keys,"prod.keys");
        File updateFile=(update==null||update.trim().isEmpty())?null:assertReadable(update,"NSP de update");
        if(updateFile!=null && !updateFile.getName().toLowerCase(Locale.ROOT).endsWith(".nsp"))throw new IOException("Update precisa ser .nsp nesta versão");
        if(!baseFile.getName().toLowerCase(Locale.ROOT).matches(".*\\.(nsp|xci)"))throw new IOException("Arquivo base precisa ser .nsp ou .xci");
        if(output==null||!output.startsWith("/storage/emulated/0/"))throw new IOException("A pasta de saída deve estar no armazenamento interno /storage/emulated/0/");
        File root=new File(output).getCanonicalFile();
        if(root.getPath().equals("/storage/emulated/0") || root.getPath().equals("/storage/emulated/0/Download"))throw new IOException("Escolha subpasta dedicada");
        if(!root.mkdirs()&&!root.isDirectory())throw new IOException("Não consegui criar a pasta de saída");
        logFile=new File(root,"moondump.log");
        File executable=new File(getApplicationInfo().nativeLibraryDir,"libmoondump_core.so");
        if(!executable.isFile())throw new IOException("Binário ARM64 ausente; compile pelo GitHub Actions antes de instalar");
        if(titlekey==null)titlekey="";
        if(!titlekey.isEmpty()&&!titlekey.matches("(?i)[0-9a-f]{32}"))throw new IOException("Title key deve conter exatamente 32 caracteres hexadecimais");
        message("Verificando arquivos. Mantendo etapas concluídas.");
        File temp=new File(root,"_nca_tmp");if(!temp.exists()&&!temp.mkdirs())throw new IOException("Não consegui criar pasta temporária");
        File baseDir=new File(temp,"base"), patchDir=new File(temp,"patch");
        String baseStamp=sha(baseFile.getAbsolutePath()+":"+baseFile.length()+":"+baseFile.lastModified());
        packageStep(executable,keysFile,baseFile,baseDir,baseStamp,"Base");
        ensureNotCancelled();
        File baseProgram=detectProgram(executable,keysFile,baseDir,titlekey);
        File patchProgram=null;
        if(updateFile!=null){
            String patchStamp=sha(updateFile.getAbsolutePath()+":"+updateFile.length()+":"+updateFile.lastModified());
            packageStep(executable,keysFile,updateFile,patchDir,patchStamp,"Update");
            ensureNotCancelled();
            patchProgram=detectProgram(executable,keysFile,patchDir,titlekey);
        }
        String dumpStamp=sha(baseStamp+(updateFile==null?"":updateFile.getAbsolutePath()+":"+updateFile.length()+":"+updateFile.lastModified())+":"+keysFile.length()+":"+keysFile.lastModified()+":"+titlekey);
        File finished=new File(root,".dump-complete");
        if(finished.isFile()&&new String(Files.readAllBytes(finished.toPath()), StandardCharsets.UTF_8).equals(dumpStamp)){
            message("Já foi concluído antes. Não há necessidade de extrair de novo.");return;
        }
        File romfs=new File(root,"romfs"),exefs=new File(root,"exefs");
        if((!romfs.isDirectory()&&!romfs.mkdirs())||(!exefs.isDirectory()&&!exefs.mkdirs()))throw new IOException("Não consegui criar romfs/exefs");
        message("Extraindo RomFS e ExeFS... arquivos finalizados serão pulados na retomada.");
        List<String> args=new ArrayList<>(Arrays.asList("-k",keysFile.getAbsolutePath(),"-t","nca","-x", "--romfsdir="+romfs.getAbsolutePath(),"--exefsdir="+exefs.getAbsolutePath()));
        if(!titlekey.isEmpty())args.add("--titlekey="+titlekey);
        if(patchProgram!=null){args.add("--basenca="+baseProgram.getAbsolutePath());args.add(patchProgram.getAbsolutePath());}
        else args.add(baseProgram.getAbsolutePath());
        runNative(executable,args);
        ensureNotCancelled();
        Files.write(finished.toPath(),dumpStamp.getBytes(StandardCharsets.UTF_8));
        message("Concluído! Verifique romfs/ e exefs/ no diretório selecionado.");
    }
    private static File assertReadable(String path,String label)throws IOException{
        if(path==null||path.trim().isEmpty())throw new IOException(label+" não informado");
        File f=new File(path).getCanonicalFile();
        if(!f.isFile()||!f.canRead())throw new IOException(label+" não acessível: "+f);
        return f;
    }
    private void packageStep(File executable,File keysFile,File src,File dir,String token,String label)throws Exception{
        if(!dir.exists()&&!dir.mkdirs())throw new IOException("Não consegui criar: "+dir);
        File completed=new File(dir,".stage-complete");
        if(completed.exists()&&new String(Files.readAllBytes(completed.toPath()), StandardCharsets.UTF_8).equals(token)){
            message(label+" já está preparado; pulando cópia de NCAs.");return;
        }
        message("Preparando NCAs: "+label+"...");
        String typ=src.getName().toLowerCase(Locale.ROOT).endsWith(".xci")?"xci":"pfs0";
        String outFlag=typ.equals("xci")?"--securedir=":"--outdir=";
        runNative(executable,Arrays.asList("-k",keysFile.getAbsolutePath(),"-t",typ,"-x",outFlag+dir.getAbsolutePath(),src.getAbsolutePath()));
        Files.write(completed.toPath(),token.getBytes(StandardCharsets.UTF_8));
    }
    private File detectProgram(File executable,File keyfile,File folder,String titlekey)throws Exception{
        File[] ncafiles=folder.listFiles(f->f.isFile()&&f.getName().toLowerCase(Locale.ROOT).endsWith(".nca"));
        if(ncafiles==null||ncafiles.length==0)throw new IOException("Nenhuma NCA encontrada: "+folder);
        Arrays.sort(ncafiles,Comparator.comparingLong(File::length).reversed());
        for(File nca:ncafiles){
            ensureNotCancelled();
            List<String> args=new ArrayList<>(Arrays.asList("-k",keyfile.getAbsolutePath(),"-t","nca","-i"));
            if(!titlekey.isEmpty())args.add("--titlekey="+titlekey);
            args.add(nca.getAbsolutePath());
            String text=runNativeCapture(executable,args,false);
            if(Pattern.compile("(?im)^\\s*Content Type\\s*:\\s*Program\\b").matcher(text).find()){
                message("Program NCA selecionada: "+nca.getName());return nca;
            }
        }
        throw new IOException("Não encontrei Program NCA. Confira as chaves; veja moondump.log");
    }
    private String runNativeCapture(File executable,List<String> args,boolean showOutput)throws Exception{
        ensureNotCancelled();
        List<String> cmd=new ArrayList<>();cmd.add(executable.getAbsolutePath());cmd.addAll(args);
        ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);
        pb.directory(getFilesDir());pb.environment().put("HOME",getFilesDir().getAbsolutePath());
        Process p=pb.start();runningProcess=p;
        StringBuilder captured=new StringBuilder();
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream(),StandardCharsets.UTF_8))){
            String line;while((line=reader.readLine())!=null){
                if(cancelled){p.destroy();break;}
                if(captured.length()<60000)captured.append(line).append('\n');
                if(showOutput){ if(line.contains("Saving")||line.contains("Error")||line.contains("Failed")||line.contains("Skipping")) message(line); }
            }
        }finally{runningProcess=null;}
        int code=p.waitFor();ensureNotCancelled();
        if(code!=0)throw new IOException("Hactool retornou "+code+": "+captured.substring(Math.max(0,captured.length()-650)));
        return captured.toString();
    }
    private void runNative(File executable,List<String> args)throws Exception{runNativeCapture(executable,args,true);}
}
