#!/usr/bin/env python3
"""Patch ISC-licensed Hactool's file writer to support atomic, safe file-level restart.
This is applied to a fresh checkout at build time. No upstream source is bundled.
"""
from pathlib import Path
import sys

p = Path(sys.argv[1])
s = p.read_text()
start = s.find('void save_file_section(FILE *f_in, uint64_t ofs, uint64_t total_size, filepath_t *filepath) {')
end = s.find('\nvalidity_t check_memory_hash_table(', start)
if start < 0 or end < 0:
    raise SystemExit('Unsupported Hactool version: could not find save_file_section()')
header = '''#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

'''
if '#include <sys/stat.h>' not in s:
    s = header + s
    start += len(header)
    end += len(header)
patched = r'''void save_file_section(FILE *f_in, uint64_t ofs, uint64_t total_size, filepath_t *filepath) {
    /* All successful files are renamed into place only after the final write.
     * An interrupted .part is never mistaken for a completed file. */
    struct stat st;
    if (stat(filepath->char_path, &st) == 0 && S_ISREG(st.st_mode) &&
        (uint64_t)st.st_size == total_size) {
        printf("Skipping existing %s (%" PRIu64 " bytes)\n", filepath->char_path, total_size);
        fflush(stdout);
        return;
    }
    size_t path_len = strlen(filepath->char_path);
    char *temporary = malloc(path_len + sizeof(".mdpart"));
    if (temporary == NULL) { perror("malloc"); exit(EXIT_FAILURE); }
    memcpy(temporary, filepath->char_path, path_len);
    memcpy(temporary + path_len, ".mdpart", sizeof(".mdpart"));
    FILE *f_out = fopen(temporary, "wb");
    if (f_out == NULL) { perror("create temporary output"); free(temporary); exit(EXIT_FAILURE); }
    unsigned char *buf = malloc(4 * 1024 * 1024);
    if (buf == NULL) { perror("malloc buffer"); fclose(f_out); free(temporary); exit(EXIT_FAILURE); }
    if (fseeko64(f_in, ofs, SEEK_SET) != 0) { perror("seek input"); exit(EXIT_FAILURE); }
    uint64_t done = 0;
    while (done < total_size) {
        size_t n = (size_t)((total_size - done) > (4ULL*1024*1024) ? 4ULL*1024*1024 : total_size-done);
        if (fread(buf, 1, n, f_in) != n) { perror("read input"); exit(EXIT_FAILURE); }
        if (fwrite(buf, 1, n, f_out) != n) { perror("write output"); exit(EXIT_FAILURE); }
        done += n;
    }
    free(buf);
    if (fflush(f_out) != 0) { perror("flush output"); exit(EXIT_FAILURE); }
    if (fclose(f_out) != 0) { perror("close output"); exit(EXIT_FAILURE); }
    if (rename(temporary, filepath->char_path) != 0) { perror("rename output"); exit(EXIT_FAILURE); }
    free(temporary);
}

'''
s=s[:start]+patched+s[end:]
p.write_text(s)
print('Patched', p)
